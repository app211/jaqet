#ifndef DEMOWIDGET_H
#define DEMOWIDGET_H

#include <QWidget>

class DemoWidget : public QWidget
{
	Q_OBJECT
public:
	explicit DemoWidget(QWidget* _parent = 0);

};

#endif // DEMOWIDGET_H
